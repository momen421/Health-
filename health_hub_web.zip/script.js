function startApp() {
  alert("Login or dashboard will be here!");
}